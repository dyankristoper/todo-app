// Style
import '../assets/styles/Footer.css';

const Footer = () => {
  return (
    <footer>All Reserved by Shuriken Realm | 2022</footer>
  )
}

export default Footer;